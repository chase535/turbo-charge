# turbo-charge

## 模块功能
删除温控，关闭阶梯式充电，持续修改电池温度及充电电流，以达到最快充电速度。配置文件在/data/adb/turbo-charge/option.txt，可以更改一些参数，即时生效

**恢复半更新状态**

我并不会适配不支持的机型，但您可通过提交PR来主动适配，亦可通过提交PR来优化程序

使用自编译的aarch64-linux-musl-gcc，项目地址：[aarch64-linux-musl-gcc](https://github.com/chase535/aarch64-linux-musl-gcc)

已经开启CI构建，可在Actions页面下载CI构建版本以获取最新测试版，**不保证CI构建版本的功能性及稳定性**

**程序遵循AGPLv3开源协议**
